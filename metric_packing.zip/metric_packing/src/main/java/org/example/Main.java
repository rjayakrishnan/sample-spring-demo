package org.example;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Main {
    
    public static int bin_size = 10;

    public static void main(String[] args) throws IOException {
        String outputPath = "/some/example/output/path";
        Random random = new Random();
        Path myPath = Paths.get("src/net/javaguides/corejava/io/JavaReadFile.java");

        System.out.println("Reading from file....");
        List< String > lines = Files.readAllLines(myPath, StandardCharsets.UTF_8);
        System.out.println("List is loaded with " + lines.size() + " entries.");
        Long[] metrics = new Long[bin_size];
        ArrayList<String>[] bins = new ArrayList[bin_size];
        Arrays.fill(metrics, 0L);

        int array_pointer = 0;
        long metric = 0l;
        System.out.println("STACKING into " + bin_size + "bins.");
        for(String line : lines){
            metric = Long.valueOf(line.split(",")[2]);

            if( array_pointer <= ( bin_size - 2 ) ){
                if( metrics[array_pointer] <= metrics[array_pointer + 1] ){

                    metrics[array_pointer] = metrics[array_pointer] + metric;
                    bins[array_pointer].add(line);

                }else{
                    array_pointer++;
                    metrics[array_pointer] = metrics[array_pointer] + metric;
                    bins[array_pointer].add(line);
                }

            }else {

                    Arrays.sort(metrics);
                    array_pointer = 0;
                    metrics[array_pointer] = metrics[array_pointer] + metric;
                    bins[array_pointer].add(line);
                    array_pointer++;
            }
        }
        array_pointer = 0;
        for(List<String> binContents : bins){
            String filename = Instant.now().toString().replace(":","-") + ".txt";
            System.out.println("Dumping contents of list with size " + binContents.size() + " to " + filename);
            System.out.println("metric size total" + metrics[array_pointer++]);
            System.out.println("------------------------------------------------------");
            Files.write(Paths.get(outputPath + filename),binContents);

        }


    }
}