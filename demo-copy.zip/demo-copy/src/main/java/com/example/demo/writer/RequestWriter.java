package com.example.demo.writer;


import java.nio.file.Files;
import java.net.URI;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;

import com.example.demo.client.DemoWebClient;
import com.example.demo.config.AppProperties;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import reactor.core.publisher.Mono;

import java.util.*;
public class RequestWriter implements ItemWriter<String> {

    @Autowired
    private AppProperties appProperties;

    private StepExecution stepExecution;
    private String shared_old;
    private String shared_new;

    private String failures;
    @Autowired
    private DemoWebClient demoWebClient;
    @BeforeStep
    public void retrieveSharedData(StepExecution stepExecution){
        System.out.println("Inside retrieveSharedData() of RequestWriter.");
        this.stepExecution = stepExecution;
        if(stepExecution.getJobExecution().getExecutionContext().get("poison-pill-stat").equals("N")){
            this.shared_old = (String) stepExecution.getJobExecution().getExecutionContext().get("cart-old");
            this.shared_new = (String) stepExecution.getJobExecution().getExecutionContext().get("cart-next");
            System.out.println("---->>>>> [JAY] retrieveSharedData- shared data is here -- " + this.shared_old);
            System.out.println("---->>>>> [JAY] retrieveSharedData- shared data is here -- " + this.shared_new);
        }else{
            System.out.println("POISON PILL WAS SET.");
        }

    }

    public Boolean postCall(Object lor){
        MultiValueMap<String, String> bodyValues = new LinkedMultiValueMap<>();
        System.out.println("postCall happening " + lor);
        bodyValues.add("master-key", (String) lor);
        bodyValues.add("prim-key", "[JAY]");
        ClientResponse response;
        Mono<String> responseMonoBody = null;
        ResponseEntity<String> responseLegacy = null;
     /*   try {
            response = demoWebClient.getClient().post()
                    .uri("http://localhost:8000")
                    .header("Authorization", "Bearer MY_SECRET_TOKEN")
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromFormData(bodyValues))
                    .exchange().block();
            System.out.println("Call for " + lor + " ends in HTTPSTATUSCODE " + response.statusCode().toString() + " ---> " + response.bodyToMono(String.class).toString());
            responseMonoBody = response.bodyToMono(String.class);
        }catch(WebClientRequestException ex){
            System.out.println("xxxx----> Problem with call on cse " + lor);
             responseMonoBody = null;
        }*/

        responseLegacy = demoWebClient.getClient().post()
                .uri("http://localhost:8000")
                .header("Authorization", "Bearer MY_SECRET_TOKEN")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromFormData(bodyValues))
                .retrieve()
                .toEntity(String.class)
                .block();

            if(responseLegacy.getStatusCode().is2xxSuccessful())
                System.out.println("Call for " + lor + " ends in HTTPSTATUSCODE " + responseLegacy.getStatusCode().toString() + " ---> " + responseLegacy.getBody().toString());
            else System.out.println("Failed for  -- " + lor);

        return responseLegacy.getStatusCode().is2xxSuccessful();
                //.exchange().block();
               // .block();


        /* return demoWebClient.getClient().post()
                .uri("http://localhost:8000")
                .header("Authorization", "Bearer MY_SECRET_TOKEN")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromFormData(bodyValues))
                .retrieve()
                .bodyToMono(String.class);*/
         //       .block();
       // return response;
    }


    @Override
    public void write(List<? extends String> listofrandoms) throws Exception {
        long generatedLong = new Random().nextLong();
        List<String> failedCases = new ArrayList<>();
        for(String r : listofrandoms)
        {
           // System.out.println("[JAY] inside write() ...[" + String.valueOf(generatedLong)+ "] -- " + r);
            //System.out.println("[JAY] inside write() ...calling webclient.");
            if(!postCall(r)) failedCases.add(r);
        }

        System.out.println("There was a total of failed cases --> " + failedCases.size());
        String filename = Instant.now().toString().replaceAll(":","-").replaceAll(".","-") + "-" + Instant.now().getNano() + ".csv";
        if(failedCases.size() > 0) Files.write(Paths.get(appProperties.getErrorFolder() + "/" + filename), failedCases);
       /* Arrays.stream(listofrandoms.toArray())//.stream(ids)
                .parallel()
                .map(this::postCall)
                .map(d -> d.share().block())
                .forEach(d -> System.out.println("in write -- " + d.toString()));
        */
      /*  Arrays.stream(listofrandoms.toArray())
                .map(this::postCall)
                .map(d -> d.share().block())
                .forEach(d -> System.out.println("in write -- " + d.toString()));*/

//write failed cases to file. filenme -- intant.now with nano . in error folder
    }
}
