package com.example.demo.processor;

import org.springframework.batch.item.ItemProcessor;
public class RequestProcessor implements ItemProcessor<String, String>{

    @Override
    public String process(String bookNameWithoutAuthor) throws Exception {
        System.out.println("[JAY] inside process() ...");
        return bookNameWithoutAuthor;
    }

}
