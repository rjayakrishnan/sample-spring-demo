package com.example.demo.reader;
import com.example.demo.config.AppProperties;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.ArrayList;
import java.util.stream.Collectors;

import org.springframework.batch.item.support.IteratorItemReader;
import org.springframework.beans.factory.annotation.Autowired;

public class RequestReader implements ItemReader<String>{

    @Autowired
    public AppProperties appProperties;
    private static List<String> attemptQueue = new ArrayList<String>();
    private String sharedold;
    private String oldcart;
    private String sharednew;

    private int increment;
    private ItemReader<String> delegate;
    private StepExecution stepExecution;

   /* public RequestReader() throws IOException {

        initialize();
    }*/
    @BeforeStep
    public void saveSharedData(StepExecution stepExecution) throws IOException {
        System.out.println("[JAY] ::saveSharedData()  beforestep called inside reader class." );
        //--

        //--
        this.stepExecution = stepExecution;

        if(Integer.valueOf(oldcart) >= appProperties.getRununtil()) {
            System.out.println("POISON CART FILE FOUND. STEP EXECUTION IS BEING SHUTDOWN.");
            this.stepExecution.getJobExecution().getExecutionContext().put("poison-pill-stat","Y");
            stepExecution.setTerminateOnly();
        }else {
            this.stepExecution.getJobExecution().getExecutionContext().put("poison-pill-stat","N");
            this.stepExecution.getJobExecution().getExecutionContext().put("cart-next",this.sharednew);
            this.stepExecution.getJobExecution().getExecutionContext().put("cart-old",this.sharedold);
        }
      //  this.shared = (String) this.stepExecution.getJobExecution().getExecutionContext().get("demo-key");
       // System.out.println("---->>>>> [JAY] - shared data is here -- " + this.shared);
    }
    @PostConstruct
    public void initialize() throws IOException {
        System.out.println("Inside RequestReader class. method : initialize()");



        try{
            List<File> filesInFolder = Files.walk(Paths.get(appProperties.getSrcfolder()))
                    .filter(Files::isRegularFile).filter(f -> f.toFile().getName().contains(".txt"))
                    .map(Path::toFile)
                    .collect(Collectors.toList());
            String cart  = filesInFolder.get(0).getName().split("[.]")[0];
            System.out.println("crt is " +filesInFolder.get(0).getName());

            oldcart = cart;
            String sharedFolder = filesInFolder.get(0).getAbsolutePath();
            increment = 1;//appProperties.getQuerybucketlimit();
            /* THIS IS HARD CODED BUT NEEDS TO BE REMOVED DURING REVIEW
            AND DYNAMICALLY SET BASED ON A CHECK ON THE NUMBER OF ENTRIES INSIDE LIST<OBJECT>
            query would return items and you keep adding it to the list until it reaches a max-processing
            size.
            while(if(attemptQueue.size() < appProperties.getQuerybucketlimit())){


                callquery(cart);
                transform_cart_to_next_value;
                add_resultset_to_list();

            }

             */
            String newFileName = String.valueOf(Integer.valueOf(cart) + increment);

            this.sharednew = appProperties.getSrcfolder() + "/" + String.join("", Collections.nCopies(5 - newFileName.length(), "0")) + newFileName + ".txt";
            this.sharedold = filesInFolder.get(0).getAbsolutePath();

            // System.out.println("---->>>>> [JAY] initialize- shared data is here -- " + this.shared);
            attemptQueue.clear();
            for (int i = 0; i < 1000; i++) {
                int generatedLong = new Random().nextInt();
                attemptQueue.add(oldcart + " - " + String.valueOf(generatedLong));
            }
        }
        catch(IOException io){

        }


    }

    @Override
public synchronized String read() throws Exception {
    System.out.println("[JAY] inside read() ...");
     /*   String attempt = null;
        if (attemptQueue.size() > 0) {
            attempt = attemptQueue.remove();
        }

        return attempt;*/
        if (delegate == null) {
            //log.info("Creating iterator item reader");
            delegate = new IteratorItemReader<>(attemptQueue);
        }
        //log.info("Reading next customer");
        return delegate.read();
}
}
