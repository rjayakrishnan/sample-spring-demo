package com.example.demo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AppProperties {

    public String getSrcfolder() {
        return srcfolder;
    }

    public void setSrcfolder(String srcfolder) {
        this.srcfolder = srcfolder;
    }

    public String getArchivefolder() {
        return archivefolder;
    }

    public void setArchivefolder(String archivefolder) {
        this.archivefolder = archivefolder;
    }

    @Value("${application.source.folder}")
    private String srcfolder;
    @Value("${application.archive.folder}")
    private String archivefolder;

    public Integer getRununtil() {
        return rununtil;
    }

    public void setRununtil(int rununtil) {
        this.rununtil = rununtil;
    }

    @Value("${rununtil}")
    private int rununtil;

    public String getQuerybucketlimit() {
        return querybucketlimit;
    }

    public void setQuerybucketlimit(String querybucketlimit) {
        this.querybucketlimit = querybucketlimit;
    }

    @Value("${querybucketlimit}")
    private String querybucketlimit;

    public String getErrorFolder() {
        return errorFolder;
    }

    public void setErrorFolder(String errorFolder) {
        this.errorFolder = errorFolder;
    }

    @Value("${application.error.folder}")
    private String errorFolder;
}

