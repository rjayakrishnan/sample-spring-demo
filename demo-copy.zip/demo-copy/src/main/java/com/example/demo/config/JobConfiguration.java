package com.example.demo.config;
import com.example.demo.listener.DemoJobListener;
import com.example.demo.listener.DemoStepListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.annotation.Configuration;
import com.example.demo.writer.RequestWriter;
import com.example.demo.reader.RequestReader;
import com.example.demo.processor.RequestProcessor;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.IOException;

@Configuration
@EnableBatchProcessing
public class JobConfiguration {
    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private DemoJobListener demoJobListener;

    @Autowired
    private DemoStepListener demoStepListener;

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private JobBuilderFactory jobBuilders;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilders;

    private static int count = 0;

    @Bean
    public Step step() {
        return this.stepBuilderFactory.get("step1").tasklet(new Tasklet() {
            @Override
            public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
                System.out.println(count + ". Hello, World!");

                count++;

                if (count < 5) {
                    return RepeatStatus.CONTINUABLE;
                } else {
                    return RepeatStatus.FINISHED;
                }

            }
        }).build();
    }
    @Scheduled(cron = "0 */1 * * * ?")
    public void run() throws Exception {
        System.out.println("[JAY] Inside jobrun call : run()....");
        JobExecution execution = jobLauncher.run(
                requestJob(),
                new JobParametersBuilder().addLong("uniqueness", System.nanoTime()).toJobParameters()
        );
       // log.info("Exit status: {}", execution.getStatus());
    }

    /*@Bean
    public Job job() {
        return this.jobBuilderFactory.get("job").start(step()).build();
    }*/
    @Bean
    public Job requestJob() throws IOException {
        System.out.println("[JAY]inside requestJob()....");
        return jobBuilders.get("requestJob")
                .listener(demoJobListener)
                .start(chunkStep())
                .build();
    }
    @Primary
    @Bean
    public TaskExecutor taskExecutor() {
        SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
        taskExecutor.setConcurrencyLimit(4);
        return taskExecutor;
    }
    @Bean
    public Step chunkStep() throws IOException {
        System.out.println("[JAY] inside chunkstep()....");
        return stepBuilders.get("chunkStep")
                .listener(demoStepListener)
                .<String, String>chunk(100)
                .reader(reader())
                .writer(writer())
                .taskExecutor(taskExecutor())
                .throttleLimit(3)
                .build();
    }
    @Bean
    public RequestProcessor processor() {
        System.out.println("[JAY] inside processor() ...");
        return new RequestProcessor();
    }

    @Bean
    @StepScope
    public RequestReader reader() throws IOException {
        System.out.println("[JAY] inside reader() ...");
        return new RequestReader();
    }

    @Bean
    public RequestWriter writer() {
        System.out.println("[JAY] inside writer() ...");
        return new RequestWriter();
    }
}