package com.example.demo.listener;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class DemoJobListener implements JobExecutionListener {
   // private StepExecution stepExecution;
    @Override
    public void beforeJob(JobExecution jobExecution) {
        System.out.println("[JAY] joblistener -- Before Job Called....");
      //  JobExecution jobExecution = stepExecution.getJobExecution();
       // ExecutionContext jobContext = jobExecution.getExecutionContext();
       // jobContext.put("demo-key","oh yeah this is awesome.");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        System.out.println("DemoJobListener -- ");
        System.out.println(jobExecution.getStatus());
        System.out.println(jobExecution.getExitStatus());
       if(!jobExecution.getStatus().equals(BatchStatus.STOPPED)){
           System.out.println("[JAY] joblistener -- After Job Called...." + jobExecution.getExecutionContext().get("cart-next"));
           System.out.println("[JAY] joblistener -- After Job Called...." + jobExecution.getExecutionContext().get("cart-old"));
           String newFile = jobExecution.getExecutionContext().get("cart-next").toString()
                   , oldFile = jobExecution.getExecutionContext().get("cart-old").toString();

           (new File(oldFile)).delete();
           try {
               (new File(newFile)).createNewFile();
           } catch (IOException e) {
               throw new RuntimeException(e);
           }
       }else{
            System.out.println("No change to newFile and oldFile.");
       }
    }
    }


