package com.example.demo.client;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import javax.xml.ws.WebEndpoint;
import java.util.Collections;

@Component
public class DemoWebClient {

    private WebClient webClient;

@Bean
    public WebClient getClient(){
         return WebClient
                .builder()
                .baseUrl("http://localhost:8000")
                .defaultCookie("Key", "Value")
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultUriVariables(Collections.singletonMap("url", "http://localhost:8080"))
                .build();
    }
}
