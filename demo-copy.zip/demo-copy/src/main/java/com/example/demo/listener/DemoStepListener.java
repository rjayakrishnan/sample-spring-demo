package com.example.demo.listener;
import com.example.demo.config.AppProperties;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.batch.core.ExitStatus;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class DemoStepListener implements StepExecutionListener {
    @Autowired
    public AppProperties appProperties;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        System.out.println("[JAY] inside steplistener Before STEP is Called....");
      /*  List<File> filesInFolder = new ArrayList<>();
        try {
            filesInFolder = Files.walk(Paths.get(appProperties.getSrcfolder()))
                    .filter(Files::isRegularFile)
                    .map(Path::toFile)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            System.out.println("omthing borke.");
            stepExecution.setTerminateOnly();
        }
        if(filesInFolder.size() < 1) {
            System.out.println("NO CART FILE FOUND. STEP EXECUTION IS BEING SHUTDOWN.");
            stepExecution.setTerminateOnly();
        }*/
    }
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        System.out.println("[JAY] inside steplistener after STEP is Called....");
        return null;
    }
}
